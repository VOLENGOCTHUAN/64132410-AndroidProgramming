public class UserInfoActivity {
}
