public class QuizActivity {
}
